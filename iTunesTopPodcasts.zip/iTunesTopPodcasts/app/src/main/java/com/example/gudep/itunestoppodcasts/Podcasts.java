package com.example.gudep.itunestoppodcasts;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

/**
 * Created by gudep on 10/3/2016.
 */

public class Podcasts implements Parcelable,Comparable<Podcasts> {
    String podcastTitle,summary;
    String thumbnailImage, bigImage;
    String  releaseDate;

    public Podcasts() {
    }

    protected Podcasts(Parcel in) {
        podcastTitle = in.readString();
        summary = in.readString();
        thumbnailImage = in.readString();
        bigImage = in.readString();
        releaseDate = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(podcastTitle);
        dest.writeString(summary);
        dest.writeString(thumbnailImage);
        dest.writeString(bigImage);
        dest.writeString(releaseDate);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Podcasts> CREATOR = new Creator<Podcasts>() {
        @Override
        public Podcasts createFromParcel(Parcel in) {
            return new Podcasts(in);
        }

        @Override
        public Podcasts[] newArray(int size) {
            return new Podcasts[size];
        }
    };

    public String getPodcastTitle() {
        return podcastTitle;
    }

    public void setPodcastTitle(String podcastTitle) {
        this.podcastTitle = podcastTitle;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getThumbnailImage() {
        return thumbnailImage;
    }

    public void setThumbnailImage(String thumbnailImage) {
        this.thumbnailImage = thumbnailImage;
    }

    public String getBigImage() {
        return bigImage;
    }

    public void setBigImage(String bigImage) {
        this.bigImage = bigImage;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    @Override
    public int compareTo(Podcasts another) {
        Date firstDate = new Date(this.getReleaseDate());
        Date secondDate = new Date(another.getReleaseDate());
        if(firstDate.compareTo(secondDate)>0) return 1;
        else if(firstDate.compareTo(secondDate)<0) return -1;
        return 0;
    }
}
