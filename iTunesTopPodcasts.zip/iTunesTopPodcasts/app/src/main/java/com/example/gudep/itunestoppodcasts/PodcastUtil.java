package com.example.gudep.itunestoppodcasts;

import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by gudep on 10/3/2016.
 */

public class PodcastUtil {

    static public class PodcastPullparser {

        static public ArrayList<Podcasts> parsePods(InputStream in) throws XmlPullParserException, IOException, ParseException {
            XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
            parser.setInput(in, "UTF-8");
            ArrayList<Podcasts> PodcastList = new ArrayList<Podcasts>();
            Podcasts pods = null;
            int event = parser.getEventType();
            while (event != XmlPullParser.END_DOCUMENT) {
                switch (event) {
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equals("entry")) {
                            pods = new Podcasts();
                        } else if (parser.getName().equals("title")) {
                                if(pods!=null) {
                                    pods.setPodcastTitle(parser.nextText().trim());
                                }
                            } else if (parser.getName().equals("summary")) {
                            if(pods!=null) {
                                pods.setSummary(parser.nextText().trim());
                            }
                            }
                            else if (parser.getName().equals("im:releaseDate")) {
                            if(pods!=null) {
                                String dateFromXml = parser.getAttributeValue(null, "label");
                                pods.setReleaseDate(dateFromXml);
                            }
                                //Date dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy kk:mm:ss zzz").parse(dateFromXml);
                                //pods.setReleaseDate(dateFormat);
                           }
                          else if (parser.getName().equals("im:image")) {
                            if (pods != null) {
                                if (parser.getAttributeValue(null, "height").equals("55")) {
                                    pods.setThumbnailImage(parser.nextText().trim());
                                } else if (parser.getAttributeValue(null, "height").equals("170")) {
                                    pods.setBigImage(parser.nextText().trim());
                                }
                            }
                        }


                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals("entry")) {
                            PodcastList.add(pods);
                            pods = null;
                        }

                        break;
                    default:
                        break;
                }
                event = parser.next();
            }
            Log.d("demo",""+PodcastList);
            return PodcastList;

        }
    }
}
