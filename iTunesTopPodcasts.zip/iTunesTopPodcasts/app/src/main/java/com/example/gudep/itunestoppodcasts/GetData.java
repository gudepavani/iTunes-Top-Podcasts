package com.example.gudep.itunestoppodcasts;

/**
 * Created by gudep on 10/3/2016.
 */


    import android.app.ProgressDialog;
    import android.content.Context;
    import android.os.AsyncTask;

    import org.xmlpull.v1.XmlPullParserException;

    import java.io.IOException;
    import java.io.InputStream;
    import java.net.HttpURLConnection;
    import java.net.MalformedURLException;
    import java.net.ProtocolException;
    import java.net.URL;
    import java.text.ParseException;
    import java.util.ArrayList;

    public class GetData extends AsyncTask<String,Void,ArrayList<Podcasts>> {

        ProgressDialog progressDialog;
        GetContext activity;

        public GetData(GetContext activity) {
            this.activity = activity;
        }

        @Override
        protected ArrayList<Podcasts> doInBackground(String... params) {

            InputStream in=null;
            try {
                URL url = new URL(params[0]);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                con.connect();
                int status= con.getResponseCode();
                if(status==HttpURLConnection.HTTP_OK){
                    in = con.getInputStream();
                    return PodcastUtil.PodcastPullparser.parsePods(in);
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            }catch (XmlPullParserException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(activity.getContext());
            progressDialog.setMessage("Loading...");
            progressDialog.setMax(100);
            progressDialog.setCancelable(false);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(ArrayList<Podcasts> podcasts) {
            super.onPostExecute(podcasts);

            activity.setupData(podcasts);
            progressDialog.dismiss();
        }

        public static interface GetContext {
            public Context getContext();
            public void setupData(ArrayList<Podcasts> podcastsArrayList);
        }
    }
