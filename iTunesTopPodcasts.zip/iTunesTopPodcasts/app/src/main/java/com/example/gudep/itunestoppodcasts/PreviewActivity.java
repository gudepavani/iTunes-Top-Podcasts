package com.example.gudep.itunestoppodcasts;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;

public class PreviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        TextView TitlePrev = (TextView) findViewById(R.id.titlePreview);
        TextView datePrev = (TextView) findViewById(R.id.DatePreview);
        TextView summary = (TextView) findViewById(R.id.Summary);
        ImageView bigImage = (ImageView) findViewById(R.id.imageViewPrev);



        Podcasts pods = (Podcasts) getIntent().getExtras().getParcelable("PodcastList");
        Date d1 = new Date(pods.getReleaseDate());
        SimpleDateFormat formattedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm aa");
        String t1 = formattedDate.format(d1);

        TitlePrev.setText(pods.getPodcastTitle());
        datePrev.setText(t1);
        summary.setText(pods.getSummary());
        Picasso.with(this).load(pods.getBigImage()).into(bigImage);
    }
}
