package com.example.gudep.itunestoppodcasts;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity implements GetData.GetContext{
    ArrayList<Podcasts> podcasts = new ArrayList<Podcasts>();
   CustomAdapter adapter;
    MainActivity activity;
    ListView listView;
    Button go, clear;
    EditText search;
    static int count=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.ListView);

        go = (Button) findViewById(R.id.GoButton);
        clear = (Button) findViewById(R.id.ClearButton);
        search = (EditText) findViewById(R.id.SearchButton);
        isConnectionOnline();
    }

    public void isConnectionOnline(){
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        if(networkInfo !=null && networkInfo.isConnected()){
            new GetData(this).execute("https://itunes.apple.com/us/rss/toppodcasts/limit=30/xml");
            //return true;
        }
        //return false;
    }


    @Override
    public Context getContext() {
        return this;
    }

    @Override
public void setupData(final ArrayList<Podcasts> podcastsArrayList) {
        Collections.sort(podcastsArrayList);
    podcasts = podcastsArrayList;
    //CustomAdapter adapter = new CustomAdapter(this, R.layout.row_layout,podcasts);
        CustomAdapter adapter = new CustomAdapter(this, R.layout.row_layout, podcastsArrayList);
        listView.setAdapter(adapter);
        adapter.setNotifyOnChange(true);

        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this, search.getText()+"hey", Toast.LENGTH_SHORT).show();
                if(search.getText().toString().equals("")){
                    Toast.makeText(MainActivity.this, "Please enter a string", Toast.LENGTH_SHORT).show();
                }
              else{
                    String str =  search.getText().toString();
                    for(int i=0; i<podcastsArrayList.size();i++){
                        if(podcastsArrayList.get(i).getPodcastTitle().toLowerCase().contains(str.toLowerCase())){
                            Podcasts p1 = podcastsArrayList.get(i);
                            podcastsArrayList.remove(i);
                            podcastsArrayList.add(0,p1);
                            count++;
                        }
                    }
                    CustomAdapter adapter = new CustomAdapter(MainActivity.this, R.layout.row_layout, podcastsArrayList);
                    listView.setAdapter(adapter);
                }
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search.setText(null);
                count=0;
                Collections.sort(podcastsArrayList);
                CustomAdapter adapter = new CustomAdapter(MainActivity.this, R.layout.row_layout, podcastsArrayList);
                listView.setAdapter(adapter);
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, PreviewActivity.class);
                intent.putExtra("PodcastList",podcastsArrayList.get(position));
                startActivity(intent);
                //Log.d("demo", "pos "+position);
            }
        });
}
}
